export const classes = [
	'sme-animation-bounce-in',
	'sme-animation-bounce-down',
	'sme-animation-fade-in',
	'sme-animation-fade-in-up',
	'sme-animation-fade-in-down',
	'sme-animation-fade-in-left',
	'sme-animation-fade-in-right',
];
