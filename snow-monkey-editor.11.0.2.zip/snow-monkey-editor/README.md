# Snow Monkey Editor

![CI](https://github.com/inc2734/snow-monkey-editor/workflows/CI/badge.svg)

See <a href="https://github.com/inc2734/snow-monkey-editor/blob/master/readme.txt">readme.txt</a>

## How to build

```
$ npm install
$ npm run build
$ composer install
```
